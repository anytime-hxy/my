﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeviceDomain
{
    public class Device
    {
        public int DeviceID { get; set; }

        public string DeviceName { get; set; }

        public string DeDetailUrl { get; set; }

        public string Type1 { get; set; }

        public string Type2 { get; set; }

        public string Type3 { get; set; }

        public string Brand { get; set; }

        public string Tag { get; set; }

    }
}
